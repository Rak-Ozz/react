import './App.css';
import ListaDeUsuarios from './Pages/ListaDeUsuarios/ListaDeUsuarios';

function App() {
  return (
    <ListaDeUsuarios></ListaDeUsuarios>
  );
}

export default App;