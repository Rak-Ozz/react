CREATE DATABASE Apostila;
USE Apostila;
 
CREATE TABLE Usuarios(
		ID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        Nome VARCHAR(255),
        Email VARCHAR(255),
        Telefone VARCHAR(255)
);
 
INSERT INTO Usuarios (Nome, Email, Telefone) Values 
('Ikki',  'ikki@saint.gk' , '(11)150854321'),
('Tony',  'tony@industries.stark' , '(33)123456789'),
('Ozzy',  'ozzman@gmail.com' , '(66)987654321'),
('Shun',  'shun@saint.gk' , '(11)150854399');

INSERT INTO Usuarios (Nome, Email, Telefone) Values 
('Sanji',  'sanji@mugiwara.pir' , '(12)150567321');